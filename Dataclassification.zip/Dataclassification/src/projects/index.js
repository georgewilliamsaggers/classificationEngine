export { default as projectsRoutes } from './routes.js';
export * as projectsService from './services.js';
export * as projectsController from './controllers.js';
