import { Router } from 'express';
import * as projectsController from './controllers.js';

const router = Router();

router.post('/', projectsController.createProject);
router.get('/', projectsController.getAllProjects);
router.get('/:id', projectsController.getProjectById);
router.put('/:id', projectsController.updateProject);
router.delete('/:id', projectsController.deleteProject);

export default router;
