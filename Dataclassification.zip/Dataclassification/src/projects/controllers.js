import * as projectsService from './services.js';

export async function createProject(req, res) {
  try {
    const { projectName, projectSpecificMetadata, projectDescription, projectStatus, projectHeader } = req.body;

    if (!projectName) {
      return res.status(400).json({ error: 'projectName is required' });
    }

    const project = await projectsService.createProject({
      projectName,
      projectSpecificMetadata,
      projectDescription,
      projectStatus,
      projectHeader
    });

    res.json({ success: true, data: project });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getAllProjects(req, res) {
  try {
    const projects = await projectsService.getAllProjects();
    res.json({ success: true, data: projects });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getProjectById(req, res) {
  try {
    const { id } = req.params;

    const project = await projectsService.getProjectById(id);
    res.json({ success: true, data: project });
  } catch (error) {
    console.error('Get project error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function updateProject(req, res) {
  try {
    const { id } = req.params;
    const updates = req.body;

    const project = await projectsService.updateProject(id, updates);
    res.json({ success: true, data: project });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function deleteProject(req, res) {
  try {
    const { id } = req.params;

    await projectsService.deleteProject(id);
    res.json({ success: true, message: `Project ${id} deleted` });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: error.message });
  }
}
