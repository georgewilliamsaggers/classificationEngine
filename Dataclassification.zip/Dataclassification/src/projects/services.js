import { supabase } from '../config/index.js';

const TABLE_NAME = 'project';

export async function createProject({ projectName, projectSpecificMetadata, projectDescription, projectStatus, projectHeader }) {
  if (!projectName) {
    throw new Error('projectName is required');
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .insert({
      project_name: projectName,
      project_specific_metadata: projectSpecificMetadata || null,
      project_description: projectDescription || null,
      project_status: projectStatus || null,
      project_header: projectHeader || null
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create project: ${error.message}`);
  }

  return data;
}

export async function getAllProjects() {
  const { data: projects, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to get projects: ${error.message}`);
  }

  // Get document counts per project
  const { data: docCounts, error: docError } = await supabase
    .from('classification_documents')
    .select('project_id');

  if (docError) {
    throw new Error(`Failed to get document counts: ${docError.message}`);
  }

  // Get extraction counts per project
  const { data: extractCounts, error: extractError } = await supabase
    .from('extractions')
    .select('project')
    .eq('deleted', false);

  if (extractError) {
    throw new Error(`Failed to get extraction counts: ${extractError.message}`);
  }

  // Count documents per project
  const docCountMap = {};
  for (const doc of docCounts || []) {
    docCountMap[doc.project_id] = (docCountMap[doc.project_id] || 0) + 1;
  }

  // Count extractions per project
  const extractCountMap = {};
  for (const ext of extractCounts || []) {
    extractCountMap[ext.project] = (extractCountMap[ext.project] || 0) + 1;
  }

  // Add counts to each project
  const projectsWithCounts = projects.map(project => ({
    ...project,
    document_count: docCountMap[project.id] || 0,
    extraction_count: extractCountMap[project.id] || 0
  }));

  return projectsWithCounts;
}

export async function getProjectById(id) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    throw new Error(`Failed to get project: ${error.message}`);
  }

  return data;
}

export async function updateProject(id, updates) {
  const allowedFields = ['project_name', 'project_specific_metadata', 'project_description', 'project_status', 'project_header'];
  const updateData = {};

  for (const field of allowedFields) {
    if (updates[field] !== undefined) {
      updateData[field] = updates[field];
    }
  }

  if (Object.keys(updateData).length === 0) {
    throw new Error('No valid fields to update');
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update project: ${error.message}`);
  }

  return data;
}

export async function deleteProject(id) {
  const { error } = await supabase
    .from(TABLE_NAME)
    .delete()
    .eq('id', id);

  if (error) {
    throw new Error(`Failed to delete project: ${error.message}`);
  }

  return true;
}
