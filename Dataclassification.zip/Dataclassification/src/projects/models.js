export const Project = {
  id: null,
  created_at: null,
  project_name: null,
  project_specific_metadata: null,
  project_description: null,
  project_status: null,
  project_header: null
};
