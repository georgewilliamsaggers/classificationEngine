import { supabase } from '../config/index.js';

const TABLE_NAME = 'extractions';

export async function createExtraction(extractionData) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .insert(extractionData)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function createExtractions(extractionsArray) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .insert(extractionsArray)
    .select();

  if (error) throw error;
  return data;
}

export async function getExtractionsByProject(projectId, codesFilter = null, codesMatch = 'or') {
  let query = supabase
    .from(TABLE_NAME)
    .select(`
      *,
      classification_documents:classificationDocument (
        file_path,
        gender,
        location,
        metadata
      )
    `)
    .eq('project', projectId)
    .eq('deleted', false);

  if (codesFilter && codesFilter.length > 0) {
    if (codesMatch === 'and') {
      query = query.contains('codes', codesFilter);
    } else {
      query = query.overlaps('codes', codesFilter);
    }
  }

  const { data, error } = await query;

  if (error) throw error;

  const flattened = data.map(item => {
    const { classification_documents, ...rest } = item;
    return {
      ...rest,
      file_path: classification_documents?.file_path || null,
      gender: classification_documents?.gender || null,
      location: classification_documents?.location || null,
      metadata: classification_documents?.metadata || null
    };
  });
//console.log(flattened)
  return flattened;
}

export async function getExtractionsByDocument(documentId) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('classificationDocument', documentId)
    .eq('deleted', false)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data;
}

export async function getExtractionById(id) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select(`
      *,
      classification_documents:classificationDocument (
        file_path,
        gender,
        location,
        metadata
      )
    `)
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
}

export async function updateExtraction(id, updateData) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateCheckedStatus(id, checked) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update({ checked })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function softDeleteExtraction(id, feedback = null) {
  const updateData = { deleted: true };
  if (feedback) {
    updateData.feedback = feedback;
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function getExtractionsByIds(ids) {
  if (!Array.isArray(ids) || ids.length === 0) {
    return [];
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select(`
      *,
      classification_documents:classificationDocument (
        file_path,
        gender,
        location,
        metadata
      )
    `)
    .in('id', ids)
    .eq('deleted', false);

  if (error) throw error;

  const flattened = data.map(item => {
    const { classification_documents, ...rest } = item;
    return {
      ...rest,
      file_path: classification_documents?.file_path || null,
      gender: classification_documents?.gender || null,
      location: classification_documents?.location || null,
      metadata: classification_documents?.metadata || null
    };
  });

  return flattened;
}

// node  src/extractions/services.js