import * as extractionService from './services.js';

export async function createOne(req, res) {
  try {
    const extraction = await extractionService.createExtraction(req.body);
    res.status(201).json(extraction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function createMany(req, res) {
  try {
    const { extractions } = req.body;
    if (!Array.isArray(extractions)) {
      return res.status(400).json({ error: 'extractions must be an array' });
    }
    const result = await extractionService.createExtractions(extractions);
    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function getByProject(req, res) {
  try {
    const { projectId } = req.params;
    let codesFilter = null;
    const codesMatch = req.query.codesMatch === 'and' ? 'and' : 'or';
    
    if (req.query.codes) {
      codesFilter = Array.isArray(req.query.codes) 
        ? req.query.codes.map(Number) 
        : req.query.codes.split(',').map(Number);
    }
    
    const extractions = await extractionService.getExtractionsByProject(projectId, codesFilter, codesMatch);
    res.json(extractions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function getByDocument(req, res) {
  try {
    const { documentId } = req.params;
    const extractions = await extractionService.getExtractionsByDocument(documentId);
    res.json({ success: true, data: extractions });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function getById(req, res) {
  try {
    const { id } = req.params;
    const extraction = await extractionService.getExtractionById(id);
    if (!extraction) {
      return res.status(404).json({ error: 'Extraction not found' });
    }
    res.json(extraction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function update(req, res) {
  try {
    const { id } = req.params;
    const extraction = await extractionService.updateExtraction(id, req.body);
    res.json(extraction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function updateChecked(req, res) {
  try {
    const { id } = req.params;
    const { checked } = req.body;

    if (typeof checked !== 'boolean') {
      return res.status(400).json({ error: 'checked must be a boolean' });
    }

    const extraction = await extractionService.updateCheckedStatus(id, checked);
    res.json({ success: true, data: extraction });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function softDelete(req, res) {
  try {
    const { id } = req.params;
    const { feedback } = req.body;
    const extraction = await extractionService.softDeleteExtraction(id, feedback);
    res.json({ success: true, data: extraction });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
