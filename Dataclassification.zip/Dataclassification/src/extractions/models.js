export const ExtractionModel = {
  tableName: 'extractions',
  fields: ['id', 'created_at', 'content', 'project', 'classificationDocument', 'code', 'deleted']
};
