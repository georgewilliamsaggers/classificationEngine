import { Router } from 'express';
import * as extractionController from './controllers.js';

const router = Router();

router.post('/', extractionController.createOne);
router.post('/bulk', extractionController.createMany);
router.get('/project/:projectId', extractionController.getByProject);
router.get('/document/:documentId', extractionController.getByDocument);
router.get('/:id', extractionController.getById);
router.put('/:id', extractionController.update);
router.patch('/:id/check', extractionController.updateChecked);
router.delete('/:id', extractionController.softDelete);

export default router;
