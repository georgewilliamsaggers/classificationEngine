export const ClassificationDocument = {
  id: null,
  created_at: null,
  project_id: null,
  content: null,
  file_path: null,
  gender: null,
  location: null,
  metadata: null
};
