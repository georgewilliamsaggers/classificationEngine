export { default as classificationRoutes } from './routes.js';
export * as classificationService from './services.js';
export * as classificationController from './controllers.js';
