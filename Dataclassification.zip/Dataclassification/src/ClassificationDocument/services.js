import mammoth from 'mammoth';
import { PDFParse } from 'pdf-parse';
import { supabase } from '../config/index.js';

const BUCKET_NAME = 'documents';
const TABLE_NAME = 'classification_documents';

export async function extractContent(fileBuffer, mimeType) {
  if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    const result = await mammoth.extractRawText({ buffer: fileBuffer });
    return result.value;
  }
  
  if (mimeType === 'text/plain') {
    return fileBuffer.toString('utf-8');
  }

  if (mimeType === 'application/pdf') {
    const parser = new PDFParse({ data: fileBuffer });
    const result = await parser.getText();
    return result.text;
  }
  
  return null;
}

export async function getFileFromStorage(filePath) {
  const { data, error } = await supabase.storage
    .from(BUCKET_NAME)
    .download(filePath);

  if (error) {
    throw new Error(`Failed to download file: ${error.message}`);
  }

  const arrayBuffer = await data.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

function getMimeType(filePath) {
  const ext = filePath.toLowerCase().split('.').pop();
  const mimeTypes = {
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'txt': 'text/plain',
    'pdf': 'application/pdf'
  };
  return mimeTypes[ext] || null;
}

export async function createDocument({ projectId, filePath, metadata, documentName }) {
  if (!projectId || !filePath) {
    throw new Error('projectId and filePath are required');
  }

  const mimeType = getMimeType(filePath);
  
  if (!mimeType) {
    throw new Error('Unsupported file type. Only .docx, .txt, and .pdf files are supported for content extraction.');
  }

  const fileBuffer = await getFileFromStorage(filePath);
  const content = await extractContent(fileBuffer, mimeType);

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .insert({
      project_id: projectId,
      file_path: filePath,
      content: content,
      metadata: metadata || null,
      document_name: documentName || null
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create document record: ${error.message}`);
  }

  return data;
}

export async function getDocumentsByProject(projectId, metadataFilters = null) {
  if (!projectId) {
    throw new Error('projectId is required');
  }

  let query = supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('project_id', projectId);

  // Apply metadata filters (AND logic - must contain all values)
  if (metadataFilters && Object.keys(metadataFilters).length > 0) {
    // Build a metadata object to check containment
    const metadataContains = {};
    for (const [key, values] of Object.entries(metadataFilters)) {
      if (Array.isArray(values) && values.length > 0) {
        metadataContains[key] = values;
      }
    }
    if (Object.keys(metadataContains).length > 0) {
      query = query.contains('metadata', metadataContains);
    }
  }

  query = query.order('created_at', { ascending: false });

  const { data, error } = await query;

  if (error) {
    throw new Error(`Failed to get documents: ${error.message}`);
  }

  return data;
}

export async function getDocumentById(id) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    throw new Error(`Failed to get document: ${error.message}`);
  }

  return data;
}

export async function updateDocument(id, updates) {
  const allowedFields = ['gender', 'location', 'metadata', 'analysis_status', 'document_name'];
  const updateData = {};

  for (const field of allowedFields) {
    if (updates[field] !== undefined) {
      updateData[field] = updates[field];
    }
  }

  if (Object.keys(updateData).length === 0) {
    throw new Error('No valid fields to update');
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update document: ${error.message}`);
  }

  return data;
}

export async function deleteDocument(id) {
  const { error } = await supabase
    .from(TABLE_NAME)
    .delete()
    .eq('id', id);

  if (error) {
    throw new Error(`Failed to delete document: ${error.message}`);
  }

  return true;
}

 