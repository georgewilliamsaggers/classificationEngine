import * as classificationService from './services.js';

export async function createDocument(req, res) {
  try {
    const { projectId, filePath, metadata, documentName } = req.body;

    if (!projectId || !filePath) {
      return res.status(400).json({ error: 'projectId and filePath are required' });
    }

    const document = await classificationService.createDocument({
      projectId,
      filePath,
      metadata,
      documentName
    });

    res.json({ success: true, data: document });
  } catch (error) {
    console.error('Create document error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getDocumentsByProject(req, res) {
  try {
    const { projectId } = req.params;

    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    // Parse metadata filters from query params
    // Reserved params that aren't metadata filters
    const reservedParams = ['projectId'];
    const metadataFilters = {};
    
    for (const [key, value] of Object.entries(req.query)) {
      if (!reservedParams.includes(key) && value) {
        // Convert comma-separated string to array
        metadataFilters[key] = Array.isArray(value) 
          ? value 
          : value.split(',').map(v => v.trim());
      }
    }

    const hasFilters = Object.keys(metadataFilters).length > 0;
    const documents = await classificationService.getDocumentsByProject(
      projectId, 
      hasFilters ? metadataFilters : null
    );
    res.json({ success: true, data: documents });
  } catch (error) {
    console.error('Get documents error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getDocumentById(req, res) {
  try {
    const { id } = req.params;

    const document = await classificationService.getDocumentById(id);
    res.json({ success: true, data: document });
  } catch (error) {
    console.error('Get document error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function updateDocument(req, res) {
  try {
    const { id } = req.params;
    const updates = { ...req.body };
    
    // Map camelCase to snake_case for database
    if (updates.documentName !== undefined) {
      updates.document_name = updates.documentName;
      delete updates.documentName;
    }

    const document = await classificationService.updateDocument(id, updates);
    res.json({ success: true, data: document });
  } catch (error) {
    console.error('Update document error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function deleteDocument(req, res) {
  try {
    const { id } = req.params;

    await classificationService.deleteDocument(id);
    res.json({ success: true, message: `Document ${id} deleted` });
  } catch (error) {
    console.error('Delete document error:', error);
    res.status(500).json({ error: error.message });
  }
}
