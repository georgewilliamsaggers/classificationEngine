import { Router } from 'express';
import * as classificationController from './controllers.js';

const router = Router();

router.post('/documents', classificationController.createDocument);
router.get('/documents/project/:projectId', classificationController.getDocumentsByProject);
router.get('/documents/:id', classificationController.getDocumentById);
router.put('/documents/:id', classificationController.updateDocument);
router.delete('/documents/:id', classificationController.deleteDocument);

export default router;
