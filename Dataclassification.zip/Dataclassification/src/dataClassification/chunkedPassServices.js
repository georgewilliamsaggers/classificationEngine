import { updateDocument } from '../ClassificationDocument/services.js'
import { getCodesByProject} from '../codes/services.js'
import { firstClassificationRound } from './classificationWorker.js'
import { createExtractions } from '../extractions/services.js'
import { getChunksByFileId, deduplicateQuotes } from './services.js'


// format for the LLM to tag array
const formatCodesForLLM = (codes) => {
  return codes.map(code => {
    let output = `# ${code.code_name}
**ID:** ${code.id}

**Description**
${code.description}
`;

    if (Array.isArray(code.examples) && code.examples.length > 0) {
      output += `
**Examples**
${code.examples.map(e => `- ${e}`).join('\n')}
`;
    }

    return output.trim();
  }).join('\n\n'); // join all codes into one big string
};

// single combined string
const getAllClassificationCodes = async (projectId) => {
  const codeBook = await getCodesByProject(projectId);
  return formatCodesForLLM(codeBook);
};

const getFileContentArray = async (fileId) => {
  const contentArray = await getChunksByFileId(fileId)
  return contentArray
} 

const createAiConfigArray = async (projectId, fileId) => {

  const fileContentArray = await getFileContentArray(fileId)
  const codes = await getAllClassificationCodes(projectId)
  let aiConfigArray = []

  fileContentArray.forEach(chunk => {

  aiConfigArray.push({

    developerPrompt : `Your role is to go through the user content and extract quotes that match the described classifications listed below. Use the extract_insights tool to return extracts that match these classifications, along with the ID of the classification itself. See the classification definitions here:

${codes}`,
    model: 'gpt-5.2',
    content : `${chunk.content}`
  })

    })

  return aiConfigArray
}

const saveClassificationToDb = async (modelResponse, projectId, fileId) => {

  const transformed = modelResponse.map(item => ({
    content: item.quote,
    codes: item.classification,
    project: projectId,
    classificationDocument: fileId
  }));

  await createExtractions(transformed)

}

const runClassificationForConfigs = async (aiConfigObjectArray) => {
  // Run all classification calls in parallel
  const promises = aiConfigObjectArray.map(async (aiConfigObject) => {
    const modelResponse = await firstClassificationRound(aiConfigObject)
    return modelResponse
  })

  const allResponses = await Promise.all(promises)
  return allResponses.flat() // flatten if each response is an array
}

export const executeChunkedClassification = async (projectId, fileId) => {
console.log("Running chunked classification")
  await updateDocument(fileId, { analysis_status: 1 }) // Set document to "in progress"

  // Prepare AI config array of objects
  const aiConfigObjectArray = await createAiConfigArray(projectId, fileId)
  console.log(`The length of the array is: ${aiConfigObjectArray.length}`)

  // Run classification function
  const modelResponseCodeArray = await runClassificationForConfigs(aiConfigObjectArray)
  console.log(`Quotation output: ${modelResponseCodeArray.length}`)

  let finalArray = modelResponseCodeArray

  // Deduplicate only if more than one chunk was passed
  if (aiConfigObjectArray.length > 1) {
    finalArray = deduplicateQuotes(modelResponseCodeArray)
    console.log(`Deduplication complete. Length: ${finalArray.length}, down from ${modelResponseCodeArray.length}`)
  }

  await saveClassificationToDb(finalArray, projectId, fileId) // save to DB
  await updateDocument(fileId, { analysis_status: 2 }) // mark document as complete

}

// node src/dataClassification/chunkedPassServices.js