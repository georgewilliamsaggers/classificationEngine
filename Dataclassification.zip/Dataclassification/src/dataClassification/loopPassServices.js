import { getDocumentById, updateDocument } from '../ClassificationDocument/services.js'
import { getCodesByProject} from '../codes/services.js'
import { firstClassificationRound } from './classificationWorker.js'
import { getChunksByFileId } from './services.js'

const formatSingleCodeForLLM = (code) => {
  let output = `# ${code.code_name}
**ID:** ${code.id}

**Description**
${code.description}
`;

  if (Array.isArray(code.examples) && code.examples.length > 0) {
    output += `
**Examples**
${code.examples.map(e => `- ${e}`).join('\n')}
`;
  }

  return output.trim();
};

// returns an array of formatted strings, one per code
const getArrayOfClassificationCodes = async (projectId) => {
  const codeBook = await getCodesByProject(projectId);
  const arrayOfCodes = codeBook.map(formatSingleCodeForLLM);
  console.log(arrayOfCodes.length)
  console.log(arrayOfCodes[0])
  return arrayOfCodes
};


getArrayOfClassificationCodes(3)

// node src/dataClassification/loopPassServices.js


// Get the content of the file
const getFileContent = async (fileId) => {
  const contentArray = await getChunksByFileId(fileId)
  return contentArray
  
} 



// set up the AI config structure
const createAiConfigs = (fileContentArray, codes) => {

  let aiConfigArray = []

  fileContentArray.forEach(chunk => {

  aiConfigArray.push({
    
    developerPrompt : `Your role is to go through the user content and extract quotes that match the following classification. Use the extract_insights tool to return extracts that match these classifications, along with the ID of the classification itself. See the classification definition here:
    
${codes}`,
    model: 'gpt-5.2',
    content : `${chunk.content}`
  })


    })

  return aiConfigArray
}

const run = async () => {
let codes = "Hell oworld codes"
let fileContentArray = await getFileContent(30)
  console.log(fileContentArray)
const classificationArray = createAiConfigs(fileContentArray, codes)
console.log(classificationArray)
}

run()














const executeClassificationLoop = async (projectId, filePath) => {
  const fileContent = await getFileContent(filePath);
  const codeContent = await getArrayOfClassificationCodes(projectId);

  const aiConfigArray = codeContent.map(code => createAiConfig(fileContent, code));

  const results = await Promise.all(
    aiConfigArray.map(aiConfig => firstClassificationRound(aiConfig))
  );

  results.forEach((res, i) => {
    console.log(`Config ${i} count: ${res.length}`);
  });
  
console.log(results)
  return results;
};



const saveClassificationToDb = async () => {
  // save the classification tags to the database
}

const updateStatusOfDocument = async () => {
  // save the classification tags to the database
}

// node src/dataClassification/loopPassServices.js