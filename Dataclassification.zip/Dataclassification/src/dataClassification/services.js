import { getDocumentById } from '../ClassificationDocument/services.js'

const estimateTokens = (text) => Math.ceil(text.length / 4)

const splitIntoSentences = (text) => {
  return text
    .replace(/\s+/g, ' ')
    .match(/[^.!?]+[.!?]+|[^.!?]+$/g) || []
}

const chunkByTokensWithOverlap = (text) => {
  const maxTokens = 2000
  const overlapTokens = 250

  const sentences = splitIntoSentences(text)
  const chunks = []

  let currentChunk = []
  let currentTokens = 0
  let index = 0

  for (const sentence of sentences) {
    const sentenceTokens = estimateTokens(sentence)

    if (currentTokens + sentenceTokens > maxTokens) {
      chunks.push({
        index,
        content: currentChunk.join(' ').trim(),
        tokenCount: currentTokens,
      })

      // overlap
      let overlapChunk = []
      let overlapCount = 0

      for (let i = currentChunk.length - 1; i >= 0; i--) {
        const tokens = estimateTokens(currentChunk[i])
        if (overlapCount + tokens > overlapTokens) break
        overlapChunk.unshift(currentChunk[i])
        overlapCount += tokens
      }

      currentChunk = overlapChunk
      currentTokens = overlapCount
      index++
    }

    currentChunk.push(sentence)
    currentTokens += sentenceTokens
  }

  if (currentChunk.length) {
    chunks.push({
      index,
      content: currentChunk.join(' ').trim(),
      tokenCount: currentTokens,
    })
  }

  return chunks
}

export const getChunksByFileId = async (fileId) => {
  const fileDetails = await getDocumentById(fileId)
  const content = fileDetails.content
  const chunks = chunkByTokensWithOverlap(content)
  return chunks 
}

export const deduplicateQuotes = (quotesArray) => {
  const quoteMap = new Map();

  for (const item of quotesArray) {
    const { quote, classification } = item;

    if (quoteMap.has(quote)) {
      // Merge classifications without duplicates
      const existingClassifications = quoteMap.get(quote);
      const merged = Array.from(new Set([...existingClassifications, ...classification]));
      quoteMap.set(quote, merged);
    } else {
      quoteMap.set(quote, classification);
    }
  }

  // Convert back to array of objects
  const deduplicatedArray = Array.from(quoteMap.entries()).map(([quote, classification]) => ({
    quote,
    classification
  }));

  return deduplicatedArray;
}
