import { Router } from 'express';
import * as classificationController from './controllers.js';

const router = Router();

router.post('/run', classificationController.runClassification);

export default router;
