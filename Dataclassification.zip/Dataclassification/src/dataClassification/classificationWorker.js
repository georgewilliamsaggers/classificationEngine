import { aiClient } from '../config/openai.js';

// this is the main service function that will be used for classification
export const firstClassificationRound =  async (aiConfig) => {

  const response = await aiClient.responses.create({
  model: aiConfig.model,
  input: [
    {
      "role": "developer",
      "content": [
        {
          "type": "input_text",
          "text": aiConfig.developerPrompt
        }
      ]
    },
    {
      "role": "user",
      "content": [
        {
          "type": "input_text",
          "text": aiConfig.content
        }
      ]
    }
  ],
  reasoning: {
    "effort": "high"
  },
  store: false,
  tools: [

    {
      "name": "extract_insights",
      "type": "function",
      "description": "Extract classified quotations from provided content and return them with classifications",
      "strict": true,
      "parameters": {
        "type": "object",
        "properties": {
          "quotes": {
            "type": "array",
            "description": "List of objects with each object holding a verbatim extract from the content and the ID of the classification",
            "items": {
              "type": "object",
              "properties": {
                "quote": {
                  "type": "string",
                  "description": "The verbatim extract from the content"
                },


                "classification": {
                  "type": "array",
                  "description": "An array of IDs for classifications that match",
                  "items": { "type": "number",
                      "description": "The ID of the classification assigned to the quote"
                    }
                }


                
              },
              "required": [
                "quote",
                "classification"
              ],
              "additionalProperties": false
            }
          }
        },
        "required": [
          "quotes"
        ],
        "additionalProperties": false
      }
    }

    /*
    {
      "name": "extract_insights",
      "type": "function",
      "description": "Extract classified quotations from provided content and return them with classifications",
      "strict": true,
      "parameters": {
        "type": "object",
        "properties": {
          "quotes": {
            "type": "array",
            "description": "List of objects with each object holding a verbatim extract from the content and the ID of the classification",
            "items": {
              "type": "object",
              "properties": {
                "quote": {
                  "type": "string",
                  "description": "The verbatim extract from the content"
                },
                "classification": {
                  "type": "number",
                  "description": "The ID of the classification assigned to the quote"
                }
              },
              "required": [
                "quote",
                "classification"
              ],
              "additionalProperties": false
            }
          }
        },
        "required": [
          "quotes"
        ],
        "additionalProperties": false
      }
    }
    */
 ]
});

  const functionCall = response.output.find(
      item => item.type === 'function_call' && item.arguments
    );
  
    if (!functionCall) return [];
  
    const output = JSON.parse(functionCall.arguments);
  return output.quotes ?? [];

}

// this is the second roudn that takes the tag array and cleans / deduplicates it
export const secondRoundDeduplication = async (tagArray) => {


  
}




// node src/dataClassification/classificationWorker.js