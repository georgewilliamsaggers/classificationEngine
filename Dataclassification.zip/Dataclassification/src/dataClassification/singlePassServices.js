import { getDocumentById, updateDocument } from '../ClassificationDocument/services.js'
import { getCodesByProject} from '../codes/services.js'
import { firstClassificationRound } from './classificationWorker.js'
import { createExtractions } from '../extractions/services.js'

// format for the LLM to tag array
const formatCodesForLLM = (codes) => {
  return codes.map(code => {
    let output = `# ${code.code_name}
**ID:** ${code.id}

**Description**
${code.description}
`;

    if (Array.isArray(code.examples) && code.examples.length > 0) {
      output += `
**Examples**
${code.examples.map(e => `- ${e}`).join('\n')}
`;
    }

    return output.trim();
  }).join('\n\n'); // join all codes into one big string
};

// single combined string
const getAllClassificationCodes = async (projectId) => {
  const codeBook = await getCodesByProject(projectId);
  return formatCodesForLLM(codeBook);
};

// Get the content of the file
const getFileContent = async (fileId) => {
  const fileDetails = await getDocumentById(fileId)
  return fileDetails.content
} 

// set up the AI config structure (specifically for the single pass)
const createAiConfig =  async (projectId, fileId) => {

  const fileContent = await getFileContent(fileId)
  const codeContent = await getAllClassificationCodes(projectId)

  let aiConfig = {
    
    developerPrompt : `Your role is to go through the user content and extract quotes that match the described classifications listed below. Use the extract_insights tool to return extracts that match these classifications, along with the ID of the classification itself. See the classification definition here:
    
${codeContent}`,
    model: 'gpt-5.2',
    content : `${fileContent}`
  }

  return aiConfig
}


const saveClassificationToDb = async (modelResponse, projectId, fileId) => {

  const transformed = modelResponse.map(item => ({
    content: item.quote,
    codes: item.classification,
    project: projectId,
    classificationDocument: fileId
  }));

  await createExtractions(transformed)

}


export const executeClassification = async (projectId, fileId) => {
  await updateDocument(fileId, { analysis_status: 1 }) // sets state of document to in progress
  const aiConfigObject = await createAiConfig(projectId, fileId) // configures the whole config file
  const modelResponse = await firstClassificationRound(aiConfigObject) // executes model in first pass
  
  // save to db 

  console.log(`Count: ${modelResponse.length}`)
  await saveClassificationToDb(modelResponse, projectId, fileId)
  await updateDocument(fileId, { analysis_status: 2 })

}



// node src/dataClassification/singlePassServices.js