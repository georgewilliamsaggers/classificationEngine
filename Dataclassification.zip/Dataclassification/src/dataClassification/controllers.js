import { executeClassification } from './singlePassServices.js';
import { updateDocument } from '../ClassificationDocument/services.js';
import { executeChunkedClassification } from './chunkedPassServices.js';

export async function runClassification(req, res) {
  try {
    const { projectId, documentIds } = req.body;

    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    if (!documentIds || !Array.isArray(documentIds) || documentIds.length === 0) {
      return res.status(400).json({ error: 'documentIds must be a non-empty array' });
    }

    if (documentIds.length > 5) {
      return res.status(400).json({ error: 'Maximum 5 documents can be classified at once' });
    }

    // Set all documents to "in progress" immediately
    await Promise.all(
      documentIds.map(docId => updateDocument(docId, { analysis_status: 1 }))
    );

    // Return 202 immediately - processing happens in background
    res.status(202).json({ 
      message: 'Classification started',
      documentIds,
      status: 'processing'
    });

    // Process classifications in background (after response sent)
    Promise.all(
      documentIds.map(async (docId) => {
        try {
          await executeChunkedClassification(projectId, docId);
        } catch (error) {
          console.error(`Classification failed for document ${docId}:`, error.message);
        }
      })
    );

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
