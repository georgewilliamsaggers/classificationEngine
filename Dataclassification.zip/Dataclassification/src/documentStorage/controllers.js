import * as storageService from './services.js';

export async function uploadDocument(req, res) {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const result = await storageService.uploadFile(
      file.originalname,
      file.buffer,
      file.mimetype
    );

    res.json({ success: true, data: result });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function listDocuments(req, res) {
  try {
    const files = await storageService.listFiles();
    res.json({ success: true, files });
  } catch (error) {
    console.error('List files error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function deleteDocument(req, res) {
  try {
    const { fileName } = req.params;
    await storageService.deleteFile(fileName);
    res.json({ success: true, message: `File ${fileName} deleted` });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ error: error.message });
  }
}
