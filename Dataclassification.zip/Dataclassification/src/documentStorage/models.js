export const BUCKET_NAME = 'documents';

export const FileMetadata = {
  name: '',
  size: 0,
  contentType: '',
  createdAt: null,
  updatedAt: null
};
