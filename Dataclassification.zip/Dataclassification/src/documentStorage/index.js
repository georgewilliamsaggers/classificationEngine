export { default as documentRoutes } from './routes.js';
export * as documentService from './services.js';
export * as documentController from './controllers.js';
