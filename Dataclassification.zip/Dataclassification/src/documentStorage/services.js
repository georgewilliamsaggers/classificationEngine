import { supabase } from '../config/index.js';

const BUCKET_NAME = 'documents';

function sanitizeFileName(fileName) {
  const ext = fileName.split('.').pop();
  const name = fileName.slice(0, fileName.lastIndexOf('.'));
  const sanitized = name
    .replace(/[|:*?"<>\/\\]/g, '-')
    .replace(/\s+/g, '_')
    .replace(/-+/g, '-')
    .replace(/_+/g, '_');
  return `${sanitized}.${ext}`;
}

export async function uploadFile(fileName, fileBuffer, contentType) {
  const safeFileName = sanitizeFileName(fileName);
  
  const { data, error } = await supabase.storage
    .from(BUCKET_NAME)
    .upload(safeFileName, fileBuffer, {
      contentType: contentType,
      upsert: true
    });

  if (error) {
    throw new Error(`Upload failed: ${error.message}`);
  }

  const { data: urlData } = supabase.storage
    .from(BUCKET_NAME)
    .getPublicUrl(safeFileName);

  return {
    path: data.path,
    originalName: fileName,
    publicUrl: urlData.publicUrl
  };
}

export async function listFiles(folder = '') {
  const { data, error } = await supabase.storage
    .from(BUCKET_NAME)
    .list(folder, {
      limit: 100,
      sortBy: { column: 'created_at', order: 'desc' }
    });

  if (error) {
    throw new Error(`List files failed: ${error.message}`);
  }

  return data;
}

export async function deleteFile(fileName) {
  const { error } = await supabase.storage
    .from(BUCKET_NAME)
    .remove([fileName]);

  if (error) {
    throw new Error(`Delete failed: ${error.message}`);
  }

  return true;
}

export async function getFileUrl(fileName) {
  const { data } = supabase.storage
    .from(BUCKET_NAME)
    .getPublicUrl(fileName);

  return data.publicUrl;
}
