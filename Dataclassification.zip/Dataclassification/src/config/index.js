export { supabase } from './supabase.js';
export { aiClient } from './openai.js';
