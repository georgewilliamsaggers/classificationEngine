import { aiClient } from '../config/openai.js';

// this is the main service function that will be used for summarisation
export const summariseData =  async (aiConfig) => {

  const response = await aiClient.responses.create({
  model: `gpt-5.2`,
  input: [
    {
      "role": "developer",
      "content": [
        {
          "type": "input_text",
          "text": aiConfig.developerPrompt
        }
      ]
    },
    {
      "role": "user",
      "content": [
        {
          "type": "input_text",
          "text": aiConfig.content
        }
      ]
    }
  ],
  reasoning: {
    "effort": "medium"
  },
  store: false
});

return response.output_text

}


// nod src/dataSummary/summaryWorker.js