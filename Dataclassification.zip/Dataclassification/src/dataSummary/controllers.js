import * as dataSummaryService from './services.js';

export async function summarizeExtractions(req, res) {
  try {
    const { extractionIds, projectId } = req.body;

    if (!extractionIds || !Array.isArray(extractionIds) || extractionIds.length === 0) {
      return res.status(400).json({ error: 'extractionIds array is required' });
    }

    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    const summary = await dataSummaryService.executeSummaryModel(extractionIds, projectId);
    res.json({ success: true, data: { summary } });
  } catch (error) {
    console.error('Summarize extractions error:', error);
    res.status(500).json({ error: error.message });
  }
}
