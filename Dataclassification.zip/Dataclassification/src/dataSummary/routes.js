import { Router } from 'express';
import * as dataSummaryController from './controllers.js';

const router = Router();

router.post('/run', dataSummaryController.summarizeExtractions);

export default router;
