import { getExtractionsByIds } from '../extractions/services.js';
import { getCodesByProject } from '../codes/services.js';
import { summariseData } from './summaryWorker.js'

const formattedExtractions = (projectCodes, selectedExtractions) => {
  const codeMap = projectCodes.reduce((acc, code) => {
    acc[code.id] = code.code_name;
    return acc;
  }, {});

  const formattedArray = selectedExtractions.map(extraction => {
    const codeNames = extraction.codes
      .map(codeId => codeMap[codeId])
      .filter(Boolean)

    return `- ${extraction.content} (${codeNames.join(', ')})`;
  });

  return formattedArray.join('\n');
}

const theExtractBase = async (codeArray, projectId) => {
  // Run both async calls concurrently
  const [projectCodes, selectedExtracts] = await Promise.all([
    getCodesByProject(projectId),
    getExtractionsByIds(codeArray)
  ]);
  const formattedExtracts = formattedExtractions(projectCodes, selectedExtracts);
  return formattedExtracts;
};

export const executeSummaryModel = async (codeArray, projectId) => {

  const configObject = {
    developerPrompt : `You are an agent responsible for summarising insights from the data the user is passing through. The user will pass n an array of extracted quotes with tags. You are to return a concise summary of the information passed and highlight key insights`,
    content : await theExtractBase(codeArray, projectId)
  }

  // execute the model
  console.log(configObject)
  const modelResponse = await summariseData(configObject)
  console.log(modelResponse)
  return modelResponse
}





// node src/dataSummary/services.js