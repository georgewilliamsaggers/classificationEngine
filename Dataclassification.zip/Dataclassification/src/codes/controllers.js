import * as codesService from './services.js';

export async function createCode(req, res) {
  try {
    const { projectId, codeName, priority, description, examples, colour } = req.body;

    if (!projectId || !codeName) {
      return res.status(400).json({ error: 'projectId and codeName are required' });
    }

    const code = await codesService.createCode({
      projectId,
      codeName,
      priority,
      description,
      examples,
      colour
    });

    res.json({ success: true, data: code });
  } catch (error) {
    console.error('Create code error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getCodesByProject(req, res) {
  try {
    const { projectId } = req.params;

    if (!projectId) {
      return res.status(400).json({ error: 'projectId is required' });
    }

    const codes = await codesService.getCodesByProject(projectId);
    res.json({ success: true, data: codes });
  } catch (error) {
    console.error('Get codes error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function getCodeById(req, res) {
  try {
    const { id } = req.params;

    const code = await codesService.getCodeById(id);
    res.json({ success: true, data: code });
  } catch (error) {
    console.error('Get code error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function updateCode(req, res) {
  try {
    const { id } = req.params;
    const updates = req.body;

    const code = await codesService.updateCode(id, updates);
    res.json({ success: true, data: code });
  } catch (error) {
    console.error('Update code error:', error);
    res.status(500).json({ error: error.message });
  }
}

export async function deleteCode(req, res) {
  try {
    const { id } = req.params;

    const code = await codesService.deleteCode(id);
    res.json({ success: true, message: `Code ${id} deleted`, data: code });
  } catch (error) {
    console.error('Delete code error:', error);
    res.status(500).json({ error: error.message });
  }
}
