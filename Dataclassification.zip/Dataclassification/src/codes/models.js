export const Code = {
  id: null,
  created_at: null,
  code_name: null,
  project_id: null,
  priority: null,
  description: null,
  examples: [],
  deleted: false,
  colour: null
};
