import { supabase } from '../config/index.js';

const TABLE_NAME = 'codes';

export async function createCode({ projectId, codeName, priority, description, examples, colour }) {
  if (!projectId || !codeName) {
    throw new Error('projectId and codeName are required');
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .insert({
      project_id: projectId,
      code_name: codeName,
      priority: priority || null,
      description: description || null,
      examples: examples || null,
      colour: colour || null,
      deleted: false
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create code: ${error.message}`);
  }

  return data;
}

export async function getCodesByProject(projectId) {
  if (!projectId) {
    throw new Error('projectId is required');
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('project_id', projectId)
    .eq('deleted', false)
    .order('priority', { ascending: true, nullsFirst: false });

  if (error) {
    throw new Error(`Failed to get codes: ${error.message}`);
  }

  return data;
}

export async function getCodeById(id) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    throw new Error(`Failed to get code: ${error.message}`);
  }

  return data;
}

export async function updateCode(id, updates) {
  const allowedFields = ['code_name', 'priority', 'description', 'examples', 'colour', 'deleted'];
  const updateData = {};

  for (const field of allowedFields) {
    if (updates[field] !== undefined) {
      updateData[field] = updates[field];
    }
  }

  if (Object.keys(updateData).length === 0) {
    throw new Error('No valid fields to update');
  }

  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update code: ${error.message}`);
  }

  return data;
}

export async function deleteCode(id) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .update({ deleted: true })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to delete code: ${error.message}`);
  }

  return data;
}
