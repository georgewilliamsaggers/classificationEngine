import { Router } from 'express';
import * as codesController from './controllers.js';

const router = Router();

router.post('/', codesController.createCode);
router.get('/project/:projectId', codesController.getCodesByProject);
router.get('/:id', codesController.getCodeById);
router.put('/:id', codesController.updateCode);
router.delete('/:id', codesController.deleteCode);

export default router;
