# Document Classification API

## Overview
Node.js Express API for document management and classification. Provides endpoints for uploading documents to Supabase Storage, managing projects and codes, and AI-powered document classification using OpenAI.

## User Preferences
- Preferred communication style: Simple, everyday language
- Modular code structure with controllers/services/routes/models per feature

## Project Structure
```
index.js                          # Express app setup, imports routes from modules
postman_collection.json           # API documentation for Postman
src/
├── config/
│   ├── index.js                  # Exports all configs
│   ├── supabase.js               # Supabase client initialization
│   └── openai.js                 # OpenAI client initialization
├── health/
│   ├── index.js                  # Module exports
│   └── routes.js                 # Health check endpoint
├── projects/
│   ├── index.js                  # Module exports
│   ├── controllers.js            # HTTP request handlers
│   ├── services.js               # Business logic
│   ├── routes.js                 # Route definitions
│   └── models.js                 # Data structures
├── documentStorage/
│   ├── index.js                  # Module exports
│   ├── controllers.js            # HTTP request handlers
│   ├── services.js               # Supabase storage operations
│   ├── routes.js                 # Route definitions
│   └── models.js                 # Data structures
├── ClassificationDocument/
│   ├── index.js                  # Module exports
│   ├── controllers.js            # HTTP request handlers
│   ├── services.js               # Content extraction + DB operations
│   ├── routes.js                 # Route definitions
│   └── models.js                 # Data structures
├── codes/
│   ├── index.js                  # Module exports
│   ├── controllers.js            # HTTP request handlers
│   ├── services.js               # Business logic
│   ├── routes.js                 # Route definitions
│   └── models.js                 # Data structures
└── extractions/
    ├── index.js                  # Module exports
    ├── controllers.js            # HTTP request handlers
    ├── services.js               # Business logic with JOIN queries
    ├── routes.js                 # Route definitions
    └── models.js                 # Data structures
```

## API Endpoints

### Health
- `GET /api/health` - Health check

### Projects
- `POST /api/projects` - Create project
- `GET /api/projects` - Get all projects
- `GET /api/projects/:id` - Get project by ID
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project

### Document Storage
- `POST /api/upload` - Upload file (form-data with 'file' field)
- `GET /api/files` - List all files
- `DELETE /api/files/:fileName` - Delete file

### Classification Documents
- `POST /api/classification/documents` - Create document record + extract content
- `GET /api/classification/documents/project/:projectId` - Get documents by project
- `GET /api/classification/documents/:id` - Get document by ID
- `PUT /api/classification/documents/:id` - Update document (gender, location, metadata)
- `DELETE /api/classification/documents/:id` - Delete document

### Codes
- `POST /api/codes` - Create code
- `GET /api/codes/project/:projectId` - Get codes by project
- `GET /api/codes/:id` - Get code by ID
- `PUT /api/codes/:id` - Update code
- `DELETE /api/codes/:id` - Soft delete code

### Extractions
- `POST /api/extractions` - Create single extraction
- `POST /api/extractions/bulk` - Create multiple extractions (array)
- `GET /api/extractions/project/:projectId` - Get extractions by project (includes parent document metadata, gender, location)
  - Query params: `codes` (comma-separated IDs), `codesMatch` ('and' or 'or')
- `GET /api/extractions/:id` - Get extraction by ID
- `PUT /api/extractions/:id` - Update extraction
- `DELETE /api/extractions/:id` - Soft delete extraction

### Classification
- `POST /api/classify/run` - Run AI classification on documents
  - Body: `{ "projectId": number, "documentIds": [number] }` (max 5 documents)

## Database Schema (Supabase)

### project
- id, created_at, project_name, project_description, project_status, project_header, project_specific_metadata (jsonb)

### classification_documents
- id, created_at, project_id, file_path, content, gender, location, metadata (jsonb), analysis_status (0=pending, 1=in progress, 2=completed, 3=failed), document_name

### codes
- id, created_at, project_id, code_name, priority, description, examples (text[]), deleted, colour

### extractions
- id, created_at, content, project (FK to project), classificationDocument (FK to classification_documents), code (FK to codes), deleted

## External Dependencies

### Supabase
- Storage bucket: `documents`
- Database tables: project, classification_documents, codes
- Environment: `SUPABASE_URL`, `SUPABASE_ANON_KEY`

### OpenAI
- SDK initialized for future AI classification
- Environment: `OPENAI_API_KEY`

### Key Packages
- express, cors, multer (file uploads)
- mammoth (Word document text extraction)
- @supabase/supabase-js

## Runtime
- Server: Port 3000, bound to 0.0.0.0
- File upload: Filename sanitization (special chars replaced)
- Content extraction: .docx and .txt files supported
