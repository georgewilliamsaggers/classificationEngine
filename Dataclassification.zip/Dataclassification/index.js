import express from 'express';
import cors from 'cors';

import { documentRoutes } from './src/documentStorage/index.js';
import { classificationRoutes } from './src/ClassificationDocument/index.js';
import { codesRoutes } from './src/codes/index.js';
import { projectsRoutes } from './src/projects/index.js';
import { healthRoutes } from './src/health/index.js';
import { extractionRoutes } from './src/extractions/index.js';
import { dataClassificationRoutes } from './src/dataClassification/index.js';
import { dataSummaryRoutes } from './src/dataSummary/index.js';

const app = express();

app.use(cors());
app.use(express.json({ limit: '50mb' }));

app.use('/api', documentRoutes);
app.use('/api/classification', classificationRoutes);
app.use('/api/codes', codesRoutes);
app.use('/api/projects', projectsRoutes);
app.use('/api/extractions', extractionRoutes);
app.use('/api/classify', dataClassificationRoutes);
app.use('/api/summary', dataSummaryRoutes);
app.use('/api', healthRoutes);

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
