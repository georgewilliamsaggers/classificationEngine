# Persisted Information

## Current State
API is running on port 3000. Just added PDF support using pdf-parse library.

## Recent Fix
- Added pdf-parse for PDF text extraction
- Used createRequire workaround for ESM compatibility
- Server restarted and running

## Completed Work
1. **Codebase Reorganization** - Modular structure with each feature in its own folder

2. **Modules Created:**
   - `src/config/` - Supabase and OpenAI clients
   - `src/health/` - Health check endpoint
   - `src/projects/` - Full CRUD
   - `src/documentStorage/` - File upload/list/delete
   - `src/ClassificationDocument/` - Document records with content extraction (docx, txt, pdf)
   - `src/codes/` - Full CRUD with soft delete

3. **API Endpoints:**
   - Health: GET /api/health
   - Projects: CRUD at /api/projects
   - Document Storage: POST /api/upload, GET /api/files, DELETE /api/files/:fileName
   - Classification Documents: CRUD at /api/classification/documents
   - Codes: CRUD at /api/codes

4. **Content Extraction Supported:**
   - .docx (mammoth)
   - .txt (native)
   - .pdf (pdf-parse) - JUST ADDED

5. **Postman Collection** - postman_collection.json with all endpoints

## Database Tables (Supabase)
- project: id, project_name, project_description, project_status, project_header, project_specific_metadata
- classification_documents: id, project_id, file_path, content, gender, location, metadata
- codes: id, project_id, code_name, priority, description, examples, deleted, colour

## File Structure
```
index.js
src/config/, src/health/, src/projects/, src/documentStorage/, src/ClassificationDocument/, src/codes/
postman_collection.json
```

## Notes
- Server on port 3000
- Supabase storage bucket "documents"
- Filename sanitization for special chars
